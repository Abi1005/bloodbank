/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.model.Blood;
import com.database.ListQuery;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author user
 */
@ManagedBean (name = "main")
@SessionScoped
public class MainController implements Serializable {
   
    ListQuery query=new ListQuery();
    private List<Blood> list=new ArrayList<Blood>();

    public List<Blood> getList() {
        list=query.listStudent();
        return list;
    }

    public void setList(List<Blood> list) {
        this.list = list;
    }
    
    
}
