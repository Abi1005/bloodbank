/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;
import java.io.Serializable;
/**
 *
 * @author user
 */
public class Blood implements Serializable {
    private int id;
    private String name;
    private String addr;
    private String cno;
    private String bgp;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getCno() {
        return cno;
    }

    public void setCno(String cno) {
        this.cno = cno;
    }

    public String getBgp() {
        return bgp;
    }

    public void setBgp(String bgp) {
        this.bgp = bgp;
    }
}
