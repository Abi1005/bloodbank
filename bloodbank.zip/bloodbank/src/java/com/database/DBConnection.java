/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.database;
import com.mysql.jdbc.Driver;
import java.sql.Connection;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author user
 */
public class DBConnection implements Serializable {
    private final String db_url="jdbc:mysql://localhost:3306/bloodbank";
    private final String db_username="root";
    private final String db_password="";
    private Connection connection=null;
    protected PreparedStatement pa=null;
    protected ResultSet rs=null;
    public Connection connect() throws SQLException{
        DriverManager.registerDriver(new Driver());
        connection=DriverManager.getConnection(db_url,db_username,db_password);
        return connection;
    }
    public void disconnect() {
        try {
            connection.close();
            pa.close();
            rs.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
