/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.database;

import com.model.Blood;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author user
 */
public class ListQuery extends DBConnection implements Serializable {
    public List<Blood> listStudent() {
        List<Blood> list=new ArrayList<Blood>();
        try {
            pa=connect().prepareStatement("select * from hospitals");
            Blood s;
            rs=pa.executeQuery();
            while(rs.next()) {
                s=new Blood();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setAddr(rs.getString("addr"));
                s.setCno(rs.getString("cno"));
                s.setBgp(rs.getString("bgp"));
                list.add(s);
            }
            return list;
        }
        catch (Exception e) {
            return null;
        }
    }

    
}
